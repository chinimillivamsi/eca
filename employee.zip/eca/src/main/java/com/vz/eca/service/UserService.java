package com.vz.eca.service;

import com.vz.eca.model.User;
import java.util.List;

public interface UserService {
    List<User> getAllUsers();
    User getUserByEid(String eid);
    void addUser(User user);
    void updateUser(User user);
    void deleteUser(String eid);
}
