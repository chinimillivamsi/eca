package com.vz.eca.model;
import java.time.LocalDate;

public class User {
	private String eid;
    private String firstName;
    private String lastName;
    private String role;
    private LocalDate addedDate;
	public User(String eid, String firstName, String lastName, String role, LocalDate addedDate) {
		super();
		this.eid = eid;
		this.firstName = firstName;
		this.lastName = lastName;
		this.role = role;
		this.addedDate = addedDate;
	}
	public User() {
		// TODO Auto-generated constructor stub
	}
	public String getEid() {
		return eid;
	}
	public void setEid(String eid) {
		this.eid = eid;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public LocalDate getAddedDate() {
		return addedDate;
	}
	public void setAddedDate(LocalDate addedDate) {
		this.addedDate = addedDate;
	}
    
    
}
