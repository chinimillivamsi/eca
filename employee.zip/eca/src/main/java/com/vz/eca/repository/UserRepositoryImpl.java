package com.vz.eca.repository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import com.vz.eca.model.User;

import jakarta.annotation.PostConstruct;

@Repository
public class UserRepositoryImpl implements UserRepository {

    private List<User> users;

    @PostConstruct
    public void init() {
        users = new ArrayList<>();
        // Initialize users from users.xml
        User u = new User();
        u.setEid("1111");
        u.setFirstName("vamsi");
        u.setLastName("ch");
        u.setRole("Admin");
        users.add(u);
        User u1 = new User();
        u1.setEid("2222");
        u1.setFirstName("krishna");
        u1.setLastName("ch");
        u1.setRole("Admin");
        
        users.add(u1);
    }

    @Override
    public List<User> getAllUsers() {
        return users;
    }

    @Override
    public User getUserByEid(String eid) {
        return users.stream()
                .filter(user -> user.getEid().equals(eid))
                .findFirst()
                .orElse(null);
    }

    @Override
    public void addUser(User user) {
        user.setAddedDate(LocalDate.now());
        users.add(user);
    }

    @Override
    public void updateUser(User user) {
        User existingUser = getUserByEid(user.getEid());
        if (existingUser != null) {
            existingUser.setFirstName(user.getFirstName());
            existingUser.setLastName(user.getLastName());
            existingUser.setRole(user.getRole());
        }
    }

    @Override
    public void deleteUser(String eid) {
        users = users.stream()
                .filter(user -> !user.getEid().equals(eid))
                .collect(Collectors.toList());
    }
}
