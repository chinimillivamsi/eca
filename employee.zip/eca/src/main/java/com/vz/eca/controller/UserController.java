package com.vz.eca.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.vz.eca.model.User;
import com.vz.eca.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/login")
    public String showLoginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String processLogin(@RequestParam("eid") String eid, Model model) {
        User user = userService.getUserByEid(eid);
        if (user != null) {
            model.addAttribute("user", user);
            return "home";
        }
        model.addAttribute("error", "Invalid EID");
        return "login";
    }

    @GetMapping("/list")
    public String showUserList(Model model) {
        List<User> userList = userService.getAllUsers();
        model.addAttribute("userList", userList);
        return "user-list";
    }

    @GetMapping("/add")
    public String showAddUserForm(Model model) {
        model.addAttribute("user", new User());
        return "user-form";
    }

    @PostMapping("/add")
    public String addUser(@ModelAttribute("user") User user) {
        userService.addUser(user);
        return "redirect:/user/list";
    }

    @GetMapping("/edit/{eid}")
    public String showEditUserForm(@PathVariable("eid") String eid, Model model) {
        User user = userService.getUserByEid(eid);
        model.addAttribute("user", user);
        return "user-form";
    }
    
    @PostMapping("/edit")
    public String updateUser(@ModelAttribute("user") User user) {
        userService.updateUser(user);
        return "redirect:/user/list";
    }

    @GetMapping("/delete/{eid}")
    public String deleteUser(@PathVariable("eid") String eid) {
        userService.deleteUser(eid);
        return "redirect:/user/list";
    }

    @GetMapping("/downloads")
    public String showDownloadsPage(Model model) {
        // Implement logic to fetch the list of files from the source folder
        List<String> files = getFilesFromSourceFolder();
        model.addAttribute("files", files);
        return "downloads";
    }
    @GetMapping("/download/{fileName}")
    public String downloadFile(@PathVariable("fileName") String fileName) {
        // Implement logic to download the file
        return "redirect:/user/downloads";
    }

    @GetMapping("/logout")
    public String logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        return "redirect:/user/login";
    }

	 // Helper method to get the list of files from the source folder
	 private List<String> getFilesFromSourceFolder() {
	     // Implement logic to fetch the list of files from the source folder
	     // and return the list of file names
	     return List.of("file1.txt", "file2.pdf", "file3.docx");
	 }
}
	 
	 