package com.vz.eca.repository;

import java.util.List;

import com.vz.eca.model.User;

public interface UserRepository {
    List<User> getAllUsers();
    User getUserByEid(String eid);
    void addUser(User user);
    void updateUser(User user);
    void deleteUser(String eid);
}
